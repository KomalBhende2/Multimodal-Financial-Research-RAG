"""
Figure Analyzer
---------------

Analyzes cropped figures.

Current Version
---------------
✓ OCR
✓ Image Size
✓ Rule-based Classification

Future
------
- Florence-2
- Qwen-VL
- BLIP-2
- GPT Vision
"""

from pathlib import Path

from PIL import Image

from ingestion.ocr.ocr_extractor import OCRExtractor


class FigureAnalyzer:

    def __init__(self):

        print("Figure Analyzer Ready.\n")

        self.ocr = OCRExtractor()

    def analyze(self, image_path):

        image_path = Path(image_path)

        print(f"Opening Image : {image_path}")

        if not image_path.exists():

            print("Image does not exist!")

            return None

        image = Image.open(image_path)

        width, height = image.size

        ocr_text = self.ocr.extract_text(image_path)
        # Clean OCR text
        ocr_text = "\n".join(

            line.strip()

            for line in ocr_text.splitlines()

            if line.strip()

)

        figure_type = self.classify(
            width,
            height,
            ocr_text
        )

        return {

            "image_path": str(image_path),

            "width": width,

            "height": height,

            "ocr_text": ocr_text,

            "figure_type": figure_type

        }

    def classify(
        self,
        width,
        height,
        text
    ):

        text = text.lower().strip()

        # Mostly text
        if len(text) > 400:

            return "text_block"

        # Financial charts
        chart_words = [

            "revenue",
            "sales",
            "profit",
            "margin",
            "ebitda",
            "pat",
            "q1",
            "q2",
            "q3",
            "q4",
            "fy",
            "%",
            "growth",
            "market",
            "volume",
            "income",
            "expenses",
            "cash",
            "assets",
            "liabilities",
            "equity"

        ]

        if any(word in text for word in chart_words):

            return "chart"

        # Logo / icon

        if len(text) < 10:

            return "logo_or_icon"

        return "figure"