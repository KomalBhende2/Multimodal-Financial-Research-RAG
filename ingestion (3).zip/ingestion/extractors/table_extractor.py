"""
Table Extractor
---------------

Extracts useful tables from PDFs using pdfplumber.

Acts as a fallback when Docling misses tables.
"""

from pathlib import Path

import pdfplumber
from rapidfuzz import fuzz

from ingestion.models.document_schema import Table


class TableExtractor:

    def extract_tables(self, pdf_path):

        print(f"\nScanning tables : {Path(pdf_path).name}")

        page_tables = {}

        with pdfplumber.open(pdf_path) as pdf:

            for page_index, page in enumerate(pdf.pages, start=1):

                recovered = []
                seen_tables = []

                try:

                    tables = page.extract_tables()

                    if not tables:
                        page_tables[page_index] = []
                        continue

                    for table in tables:

                        if not table:
                            continue

                        cleaned_rows = []

                        for row in table:

                            if row is None:
                                continue

                            cleaned = []

                            for cell in row:

                                if cell is None:
                                    cleaned.append("")

                                else:

                                    value = " ".join(
                                        str(cell).replace("\n", " ").split()
                                    )

                                    cleaned.append(value)

                            # Skip completely empty rows
                            if any(cell != "" for cell in cleaned):
                                cleaned_rows.append(cleaned)

                        # -------------------------
                        # Empty table
                        # -------------------------

                        if not cleaned_rows:
                            continue

                        row_count = len(cleaned_rows)
                        col_count = max(len(r) for r in cleaned_rows)

                        # -------------------------
                        # Ignore fake tables
                        # -------------------------

                        if row_count < 2:
                            continue

                        if col_count < 2:
                            continue

                        # -------------------------
                        # Ignore extremely tiny tables
                        # -------------------------

                        total_text = " ".join(
                            " ".join(r)
                            for r in cleaned_rows
                        )

                        if len(total_text.strip()) < 20:
                            continue

                        # -------------------------
                        # Duplicate check
                        # -------------------------

                        duplicate = False

                        for previous in seen_tables:

                            score = fuzz.ratio(
                                total_text,
                                previous
                            )

                            if score > 95:
                                duplicate = True
                                break

                        if duplicate:
                            continue

                        seen_tables.append(total_text)

                        recovered.append(

                            Table(

                                title="Recovered Table",

                                rows=cleaned_rows,

                                source="pdfplumber"

                            )

                        )

                except Exception as e:

                    print(
                        f"Page {page_index}: {e}"
                    )

                page_tables[page_index] = recovered

        return page_tables