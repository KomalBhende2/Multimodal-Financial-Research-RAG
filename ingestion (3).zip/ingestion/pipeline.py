"""
Memory Optimized Ingestion Pipeline
----------------------------------

Processes PDFs in batches (default: 5 pages).

This prevents Docling, OCR and Table extraction
from loading the entire PDF into RAM.
"""

from pathlib import Path
import gc
import fitz

from ingestion.extractors.docling_extractor import DoclingExtractor
from ingestion.extractors.table_extractor import TableExtractor

from ingestion.processors.document_parser import DocumentParser
from ingestion.processors.metadata_enricher import MetadataEnricher
from ingestion.processors.figure_processor import FigureProcessor
from ingestion.processors.text_cleaner import TextCleaner
from ingestion.processors.deduplicator import Deduplicator
from ingestion.processors.document_builder import DocumentBuilder


class IngestionPipeline:

    def __init__(self, batch_size=5):

        self.batch_size = batch_size

        self.docling = DoclingExtractor()
        self.parser = DocumentParser()
        self.metadata = MetadataEnricher()
        self.tables = TableExtractor()
        self.figures = FigureProcessor()
        self.cleaner = TextCleaner()
        self.deduplicator = Deduplicator()
        self.builder = DocumentBuilder()

    # ----------------------------------------------------
    # Create Batch PDF
    # ----------------------------------------------------

    def _save_batch(self, pdf_path, start_page, end_page):

        original = fitz.open(pdf_path)

        batch_pdf = fitz.open()

        for page in range(start_page, end_page):

            batch_pdf.insert_pdf(
                original,
                from_page=page,
                to_page=page
            )

        batch_folder = Path("temp_pdf_batches")

        batch_folder.mkdir(exist_ok=True)

        temp_pdf = batch_folder / f"batch_{start_page+1}_{end_page}.pdf"

        if temp_pdf.exists():
            temp_pdf.unlink()

        batch_pdf.save(str(temp_pdf))

        batch_pdf.close()

        original.close()

        return temp_pdf

    # ----------------------------------------------------
    # MAIN
    # ----------------------------------------------------

    def process_pdf(self, pdf_path):

        pdf_path = Path(pdf_path)

        pdf = fitz.open(pdf_path)

        total_pages = len(pdf)

        pdf.close()

        print("=" * 70)
        print("Processing :", pdf_path.name)
        print("Total Pages :", total_pages)
        print("Batch Size :", self.batch_size)
        print("=" * 70)

        all_pages = []

        recovered_tables = {}

        recovered_figures = []

        # ------------------------------------------------

        for start in range(0, total_pages, self.batch_size):

            end = min(start + self.batch_size, total_pages)

            print(f"\nProcessing Pages {start+1} -> {end}")

            temp_pdf = self._save_batch(
                pdf_path,
                start,
                end
            )

            try:

                # ------------------------------
                # Docling
                # ------------------------------

                docling_doc = self.docling.extract(temp_pdf)

                # ------------------------------
                # Parse
                # ------------------------------

                document = self.parser.parse(
                    docling_doc,
                    pdf_path.name
                    
                )
                

                # Fix page numbers

                for page in document.pages:
                    page.page_number += start

                all_pages.extend(document.pages)

                # ------------------------------
                # Tables
                # ------------------------------

                batch_tables = self.tables.extract_tables(
                    temp_pdf
        )

                print("\n========== TABLE DEBUG ==========")
                print("Type:", type(batch_tables))
                print("Value:")
                print("\n========== TABLE DEBUG ==========")
                print(type(batch_tables))
                print(batch_tables.keys())

                for p, t in batch_tables.items():
                    print(f"Page {p}: {len(t)} tables")

                
                print("=================================\n")

                for page_no, tables in batch_tables.items():

                    original_page = page_no + start

                    recovered_tables[original_page] = tables
                # ------------------------------
                # Figures
                # ------------------------------

                batch_figures = self.figures.process(
                    temp_pdf,
                    docling_doc
                )

                for fig in batch_figures:
                    fig.page_number += start

                recovered_figures.extend(batch_figures)

            finally:

                # Delete temporary PDF

                try:
                    temp_pdf.unlink()
                except:
                    pass

                gc.collect()

        # ------------------------------------------------

        document.pages = all_pages

        print()
        print("Pages Parsed :", len(document.pages))

        document = self.metadata.enrich(document)

        for fig in recovered_figures:

            if 1 <= fig.page_number <= len(document.pages):

                document.pages[
                    fig.page_number - 1
                ].figures.append(fig)

        document = self.cleaner.clean(document)

        document = self.deduplicator.merge(
            document,
            recovered_tables
        )

        output = self.builder.build(
            document,
            output_folder="ingestion/output"
        )

        return output