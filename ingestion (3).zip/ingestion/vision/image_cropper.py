"""
Image Cropper
-------------

Uses Docling picture bounding boxes and PyMuPDF
to crop high-resolution figures from the original PDF.

Output
------
data/extracted_figures/<pdf_name>/
"""

from pathlib import Path

import fitz  # PyMuPDF


class ImageCropper:

    def __init__(self, dpi=300):

        self.dpi = dpi

        print(f"Image Cropper Ready ({dpi} DPI)\n")

    def extract(
        self,
        pdf_path,
        docling_document
    ):

        pdf_path = Path(pdf_path)

        output_folder = (
            Path("data")
            / "extracted_figures"
            / pdf_path.stem
        )

        output_folder.mkdir(
            parents=True,
            exist_ok=True
        )

        saved = []

        zoom = self.dpi / 72
        matrix = fitz.Matrix(zoom, zoom)

        pdf = None

        try:

            pdf = fitz.open(pdf_path)

            for index, picture in enumerate(
                docling_document.pictures,
                start=1
            ):

                if not picture.prov:
                    continue

                prov = picture.prov[0]

                page_no = prov.page_no

                page = pdf.load_page(page_no - 1)

                bbox = prov.bbox

                page_height = page.rect.height

                # Convert Docling coordinates
                rect = fitz.Rect(
                    bbox.l,
                    page_height - bbox.t,
                    bbox.r,
                    page_height - bbox.b
                )

                # Ignore invalid rectangles
                if rect.is_empty or rect.width <= 0 or rect.height <= 0:
                    continue

                pix = page.get_pixmap(
                    matrix=matrix,
                    clip=rect,
                    alpha=False
                )

                image_path = (
                    output_folder
                    / f"page_{page_no}_figure_{index}.png"
                )

                pix.save(image_path)

                saved.append(
                    {
                        "page": page_no,
                        "path": str(image_path),
                        "bbox": rect
                    }
                )

        except Exception as e:

            print(f"Image Cropper Error: {e}")

        finally:

            if pdf is not None:
                pdf.close()

        print(f"Saved {len(saved)} images")

        return saved