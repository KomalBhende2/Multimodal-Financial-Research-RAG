"""
Text Cleaner
------------

Cleans extracted document text.
"""


class TextCleaner:

    def clean(self, document):

        for page in document.pages:

            for paragraph in page.paragraphs:

                text = paragraph.text

                text = text.replace("\xa0", " ")

                text = " ".join(text.split())

                paragraph.text = text

        return document