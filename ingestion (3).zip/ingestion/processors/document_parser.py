"""
Production Document Parser
--------------------------

Converts DoclingDocument into our internal schema.

Preserves reading order and captures:
- Titles
- Headings
- Paragraphs
- Lists
- Tables
- Figures

"""

from ingestion.models.document_schema import (
    Document,
    Page,
    Paragraph,
    Table,
    Figure,
)


class DocumentParser:

    def parse(self, doc, filename=""):

        document = Document(filename=filename)

        pages = {}

        total_pages = doc.num_pages()

        for page_no in range(1, total_pages + 1):
            pages[page_no] = Page(page_number=page_no)

        # Track extraction stats
        items_processed = 0
        items_with_prov = 0
        items_without_prov = 0

        # ----------------------------------------------------
        # Iterate through Docling items
        # ----------------------------------------------------

        for item, level in doc.iterate_items():
            items_processed += 1
            
            print("=" * 60)
            print(type(item))
            print("Label :", getattr(item, "label", ""))
            print("Text :", getattr(item, "text", "")[:80])

            if hasattr(item, "prov") and item.prov:
                print("Page :", item.prov[0].page_no)
                items_with_prov += 1
            else:
                items_without_prov += 1
                print("[WARNING] Item has NO PROVENANCE")

            if not hasattr(item, "prov"):
                continue

            if not item.prov:
                continue

            page_no = item.prov[0].page_no
            print("--------------------------------")
            print("PAGE :", page_no)
            print("LABEL :", getattr(item, "label", ""))
            print("TEXT :", getattr(item, "text", "")[:80])

            if page_no not in pages:
                continue

            page = pages[page_no]

            label = str(getattr(item, "label", "")).lower()

            text = getattr(item, "text", "")

            if text is None:
                text = ""

            text = text.strip()

            # ----------------------------------------------------
            # Ignore empty text
            # ----------------------------------------------------

            if text == "" and "table" not in label and "picture" not in label:
                continue

            # ----------------------------------------------------
            # TITLE
            # ----------------------------------------------------

            if "title" in label:

                if not page.title:
                    page.title = text

                page.paragraphs.append(
                    Paragraph(
                        text=text,
                        heading_level=0,
                        source="docling"
                    )
                )

                continue

            # ----------------------------------------------------
            # HEADINGS
            # ----------------------------------------------------

            if (
                "section_header" in label
                or "heading" in label
                or "header" in label
            ):

                if not page.title:
                    page.title = text

                page.paragraphs.append(
                    Paragraph(
                        text=text,
                        heading_level=1,
                        source="docling"
                    )
                )

                continue

            # ----------------------------------------------------
            # LIST ITEMS
            # ----------------------------------------------------

            if "list" in label:

                page.paragraphs.append(
                    Paragraph(
                        text=text,
                        heading_level=0,
                        source="docling"
                    )
                )

                continue

            # ----------------------------------------------------
            # NORMAL TEXT
            # ----------------------------------------------------

            if (
                "text" in label
                or "paragraph" in label
            ):

                if not page.title:

                    if len(text) < 120:
                        page.title = text

                page.paragraphs.append(
                    Paragraph(
                        text=text,
                        heading_level=0,
                        source="docling"
                    )
                )

                continue

            # ----------------------------------------------------
            # TABLE
            # ----------------------------------------------------

            if "table" in label:

                rows = []

                try:
                    df = item.export_to_dataframe()
                    rows = df.fillna("").values.tolist()

                except Exception:
                    pass

                page.tables.append(
                    Table(
                        title="",
                        rows=rows,
                        page_number=page_no,
                        source="docling"
                    )
                )

                continue

            # ----------------------------------------------------
            # FIGURE
            # ----------------------------------------------------

        

            

                continue

        document.pages = [pages[i] for i in sorted(pages)]
        
        # -------------------------------------------------
        # Extraction Summary
        # -------------------------------------------------
        print("\n" + "=" * 60)
        print("EXTRACTION SUMMARY")
        print("=" * 60)
        print(f"Total items processed: {items_processed}")
        print(f"Items with provenance: {items_with_prov}")
        print(f"Items without provenance: {items_without_prov}")
        
        pages_with_content = sum(1 for p in document.pages if len(p.paragraphs) > 0 or len(p.tables) > 0 or len(p.figures) > 0)
        pages_empty = len(document.pages) - pages_with_content
        
        print(f"\nPages with content: {pages_with_content}/{len(document.pages)}")
        print(f"Pages empty: {pages_empty}/{len(document.pages)}")
        
        # Show empty pages
        if pages_empty > 0:
            empty_page_nums = [p.page_number for p in document.pages if len(p.paragraphs) == 0 and len(p.tables) == 0 and len(p.figures) == 0]
            print(f"\n[EMPTY PAGES] {empty_page_nums}")
            print("  --> These pages may be scanned images or visual-only content")
            print("  --> Consider applying OCR to these pages")
        
        print("=" * 60 + "\n")

        return document