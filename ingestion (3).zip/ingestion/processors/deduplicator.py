"""
Deduplicator
------------

Removes duplicate paragraphs and merges recovered tables.
"""

from rapidfuzz import fuzz


class Deduplicator:

    def merge(
        self,
        document,
        recovered_tables
    ):

        # --------------------------------
        # Merge Tables
        # --------------------------------

        for page_no, tables in recovered_tables.items():

            if page_no <= len(document.pages):

                document.pages[page_no - 1].tables.extend(tables)

        # --------------------------------
        # Remove Duplicate Paragraphs
        # --------------------------------

        for page in document.pages:

            unique = []

            cleaned = []

            for paragraph in page.paragraphs:

                duplicate = False

                for old in unique:

                    score = fuzz.ratio(
                        paragraph.text,
                        old
                    )

                    if score > 95:

                        duplicate = True

                        break

                if not duplicate:

                    unique.append(paragraph.text)

                    cleaned.append(paragraph)

            page.paragraphs = cleaned

        return document