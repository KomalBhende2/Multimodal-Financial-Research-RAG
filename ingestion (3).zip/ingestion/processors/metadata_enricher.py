"""
Metadata Enricher
-----------------

Adds production-ready metadata for every document and page.
"""

import re
from pathlib import Path


class MetadataEnricher:

    def enrich(self, document):

        filename = Path(document.filename).stem

        # -------------------------------------------------
        # Document Metadata
        # -------------------------------------------------

        document.company = "Ather Energy"

        document.document_type = "Investor Presentation"

        document.fiscal_year = "FY2026"

        document.quarter = "Q1"

        document.metadata = {

            "filename": filename,

            "company": document.company,

            "document_type": document.document_type,

            "fiscal_year": document.fiscal_year,

            "quarter": document.quarter,

            "total_pages": len(document.pages)

        }

        # -------------------------------------------------
        # Page Metadata
        # -------------------------------------------------

        financial_words = {

            "revenue",
            "ebitda",
            "pat",
            "margin",
            "income",
            "sales",
            "profit",
            "cash",
            "expenses"

        }

        entity_words = {

            "ather",
            "rizta",
            "halo",
            "450",
            "ather grid",
            "atherstack",
            "blzin",
            "el platform"

        }

        keyword_words = {

            "ev",
            "electric",
            "scooter",
            "battery",
            "charging",
            "manufacturing",
            "platform",
            "software",
            "dealer",
            "retail"

        }

        for page in document.pages:

            full_text = " ".join(

                paragraph.text

                for paragraph in page.paragraphs

            )

            lower_text = full_text.lower()

            numbers = re.findall(r"\d+", full_text)

            financial_metrics = [

                word

                for word in financial_words

                if word in lower_text

            ]

            entities = [

                word

                for word in entity_words

                if word in lower_text

            ]

            keywords = [

                word

                for word in keyword_words

                if word in lower_text

            ]

            has_chart = any(

                figure.figure_type == "chart"

                for figure in page.figures

            )

            page.metadata = {

                "page_number": page.page_number,

                "section": page.title,

                "subsection": "",

                "heading": page.title,

                "parent_heading": "",

                "chunk_type": "page",

                "has_table": len(page.tables) > 0,

                "has_chart": has_chart,

                "has_numbers": len(numbers) > 0,

                "entities": entities,

                "financial_metrics": financial_metrics,

                "keywords": keywords

            }

        return document