"""
Figure Processor
----------------

Processes every figure found by Docling.

Pipeline

Docling Picture
      ↓
Crop Image
      ↓
OCR
      ↓
Classification
      ↓
Figure Schema
"""

from ingestion.models.document_schema import Figure
from ingestion.vision.image_cropper import ImageCropper
from ingestion.analyzers.figure_analyzer import FigureAnalyzer


class FigureProcessor:

    def __init__(self):

        print("Figure Processor Ready.\n")

        self.cropper = ImageCropper()

        self.analyzer = FigureAnalyzer()

    def process(
        self,
        pdf_path,
        docling_document
    ):

        # Crop all figures
        cropped_images = self.cropper.extract(
            pdf_path,
            docling_document
        )

        figures = []

        # Analyze every cropped image
        for image in cropped_images:

            analysis = self.analyzer.analyze(
                image["path"]
            )

            # Skip tiny icons
            if (
                analysis["figure_type"] == "logo_or_icon"
                and len(analysis["ocr_text"]) < 5
            ):
    
                continue

            figure = Figure(

                image_path=analysis["image_path"],

                caption="",

                ocr_text=analysis["ocr_text"],

                figure_type=analysis["figure_type"],

                width=analysis["width"],

                height=analysis["height"],

                source="docling",

                page_number=image["page"]

            )

            figures.append(figure)

        print(f"Figures Processed : {len(figures)}")

        return figures