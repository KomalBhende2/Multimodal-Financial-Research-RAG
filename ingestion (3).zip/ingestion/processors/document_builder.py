"""
Document Builder
----------------

Converts the parsed Document object into a clean
human-readable text file.

This version also exports page metadata so that
chunking becomes much easier later.
"""

from pathlib import Path


class DocumentBuilder:

    def build(
        self,
        document,
        output_folder="ingestion/output"
    ):

        Path(output_folder).mkdir(
            parents=True,
            exist_ok=True
        )

        output_file = (
            Path(output_folder)
            / f"{Path(document.filename).stem}.txt"
        )

        with open(
            output_file,
            "w",
            encoding="utf-8"
        ) as f:

            # ====================================================
            # Document Metadata
            # ====================================================

            f.write("=" * 80 + "\n")
            f.write("DOCUMENT METADATA\n")
            f.write("=" * 80 + "\n\n")

            f.write(f"Company           : {document.company}\n")
            f.write(f"Document Type     : {document.document_type}\n")
            f.write(f"Fiscal Year       : {document.fiscal_year}\n")
            f.write(f"Quarter           : {document.quarter}\n")
            f.write(f"Total Pages       : {len(document.pages)}\n\n")

            # ====================================================
            # Pages
            # ====================================================

            for page in document.pages:

                f.write("=" * 80 + "\n")

                f.write(f"Page : {page.page_number}\n\n")

                # ------------------------------------------
                # Metadata
                # ------------------------------------------

                f.write("Metadata\n")
                f.write("-" * 40 + "\n")

                for key, value in page.metadata.items():

                    if isinstance(value, list):

                        value = ", ".join(value)

                    f.write(f"{key:<20}: {value}\n")

                f.write("\n")

                # ------------------------------------------
                # Title
                # ------------------------------------------

                f.write("Title\n")
                f.write("-" * 40 + "\n")

                f.write(page.title)

                f.write("\n\n")

                # ------------------------------------------
                # Text
                # ------------------------------------------

                f.write("Extracted Text\n")
                f.write("-" * 40 + "\n\n")

                for paragraph in page.paragraphs:

                    f.write(paragraph.text)

                    f.write("\n\n")

                # ------------------------------------------
                # Tables
                # ------------------------------------------

                if page.tables:

                    f.write("Tables\n")

                    f.write("-" * 40 + "\n")

                    for table in page.tables:

                        if table.title:

                            f.write(table.title)

                            f.write("\n")

                        for row in table.rows:

                            f.write(" | ".join(row))

                            f.write("\n")

                        f.write("\n")

                # ------------------------------------------
                # Figures
                # ------------------------------------------

                if page.figures:

                    f.write("Figures\n")

                    f.write("-" * 40 + "\n")

                    for figure in page.figures:

                        f.write(
                            f"Type : {figure.figure_type}\n"
                        )

                        f.write(
                            f"Image : {figure.image_path}\n"
                        )

                        f.write(
                            f"Size : {figure.width} x {figure.height}\n"
                        )

                        if figure.ocr_text:

                            f.write("OCR Text:\n")

                            f.write(figure.ocr_text)

                            f.write("\n")

                        f.write("\n")

                f.write("\n")

        print(f"\nSaved : {output_file}")

        return output_file