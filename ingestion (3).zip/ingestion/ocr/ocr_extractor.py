"""
OCR Extractor
-------------

Extracts text from images using RapidOCR.
Supports both older and newer RapidOCR versions.
"""

from pathlib import Path
from rapidocr import RapidOCR


class OCRExtractor:

    def __init__(self):

        print("Loading OCR Engine...")

        self.engine = RapidOCR()

        print("OCR Ready.\n")

    def extract_text(self, image_path):

        image_path = Path(image_path)

        if not image_path.exists():
            print("Image not found:", image_path)
            return ""

        try:

            result = self.engine(str(image_path))

        except Exception as e:

            print("OCR Error:", e)
            return ""

        if result is None:
            return ""

        # -------------------------------------------------
        # Debug Information
        # -------------------------------------------------

        print("\n========================================")
        print("OCR RESULT TYPE")
        print("========================================")
        print(type(result))

        # -------------------------------------------------
        # RapidOCR 3.x
        # -------------------------------------------------

        if hasattr(result, "txts"):

            print("Detected RapidOCR 3.x")

            if result.txts:
                return "\n".join(result.txts)

            return ""

        # -------------------------------------------------
        # Older RapidOCR versions
        # -------------------------------------------------

        if isinstance(result, tuple):

            result = result[0]

        if result is None:
            return ""

        lines = []

        try:

            for item in result:

                if len(item) >= 2:

                    lines.append(item[1])

        except Exception as e:

            print("Parsing Error:", e)
            return ""

        return "\n".join(lines)