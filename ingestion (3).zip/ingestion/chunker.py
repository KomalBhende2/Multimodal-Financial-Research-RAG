"""
Semantic Chunker
----------------

Creates intelligent chunks while preserving document structure.
"""

import uuid

from typing import List


class SemanticChunker:

    def __init__(

        self,

        max_words=350

    ):

        self.max_words = max_words

    def _word_count(self, text):

        return len(text.split())

    def create_chunks(self, document):

        chunks = []

        for page in document.pages:

            current_chunk = ""

            current_words = 0

            title = page.title.strip()

            if title:

                current_chunk += f"# {title}\n\n"

                current_words += self._word_count(title)

            # -----------------------
            # Paragraphs
            # -----------------------

            for para in page.paragraphs:

                words = self._word_count(para.text)

                if current_words + words > self.max_words:

                    chunks.append(

                        {

                            "chunk_id": str(uuid.uuid4()),

                            "page": page.page_number,

                            "text": current_chunk.strip(),

                            "metadata": page.metadata

                        }

                    )

                    current_chunk = ""

                    current_words = 0

                current_chunk += para.text + "\n\n"

                current_words += words

            # -----------------------
            # Tables
            # -----------------------

            for table in page.tables:

                table_text = ""

                if table.title:

                    table_text += table.title + "\n"

                for row in table.rows:

                    table_text += " | ".join(row) + "\n"

                words = self._word_count(table_text)

                if current_words + words > self.max_words:

                    chunks.append(

                        {

                            "chunk_id": str(uuid.uuid4()),

                            "page": page.page_number,

                            "text": current_chunk.strip(),

                            "metadata": page.metadata

                        }

                    )

                    current_chunk = ""

                    current_words = 0

                current_chunk += "\n" + table_text + "\n"

                current_words += words

            if current_chunk.strip():

                chunks.append(

                    {

                        "chunk_id": str(uuid.uuid4()),

                        "page": page.page_number,

                        "text": current_chunk.strip(),

                        "metadata": page.metadata

                    }

                )

        return chunks